﻿=== Simple LiqPay ===
Contributors: Alex Shandor
Donate link: http://pupuga.net
Tags: woocommerce, LiqPay
Requires at least: 4.1
Tested up to: 4.3
Stable tag: 4.1
License: MIT

== Description ==

This plugin is the gateway for LiqPay system of woocommerce

github - https://github.com/pupuga/simple-lqpay

== Installation ==

1. Разархивируйте содержимое zip файла в папку плагинов вашего сайта (wp-content/plugins/), используя вашу любимую FTP программу.
3. Активируйте плагин на странице "Плагины" в панели администратора.
4. Укажите публичный и приватный ключ в настройках Woocommerce - Закладка LiqPay.
5. Установка завершена.

== Changelog ==

= 1.0 =
* Выпуск релиза.

= 1.1 =
* Добален выбор языка интерфеса LiqPay.
* Добавлена возможность изменения логотипа на странице заказа.

= 1.2 =
* Добалена возможность выбора статуса заказа после успешной оплаты заказа.

= 1.3 =
* Bug Fix http/https

= 1.3.1 =
* Bug Fix

= 1.4 =
* Возможность использования в интерфейсе двух языков

= 1.5 =
* Добавлена возможность добавить Thanks Page
* Добавлена возможность передачи в LiqPay своего номера заказа

= 1.5.1 =
* Bug Fix

= 1.6 =
* Добавлена возможность, изменять изображение кнопки - ОПЛАТИТЬ

= 1.7 =
* замена www.liqpay.com на www.liqpay.ua